document.getElementById("uploadBtn").addEventListener("click", async () => {
  const fileInput = document.getElementById("fileInput");
  const result = document.getElementById("result");
  result.innerHTML = "";

  if (!fileInput.files.length) {
    result.innerHTML = '<div class="error">Please select a CSV file.</div>';
    return;
  }

  const formData = new FormData();
  formData.append("file", fileInput.files[0]);

  try {
    const response = await fetch("/api/upload", {
      method: "POST",
      body: formData
    });

    if (!response.ok) {
      result.innerHTML = '<div class="error">❌ Server error: ' + response.status + '</div>';
      return;
    }

    const data = await response.json();

    if (data.status === "success") {
      result.innerHTML = '<div class="success">✅ All good! No validation errors.</div>';
    } else if (data.status === "error") {
      let html = '<div class="error"><b>Validation Errors:</b><ul>';
      if (Array.isArray(data.errors)) {
        data.errors.forEach(err => {
          html += `<li>Row ${err.row}: ${err.message}</li>`;
        });
      }
      html += "</ul></div>";
      result.innerHTML = html;
    } else {
      result.innerHTML = '<div class="error">Unexpected JSON format from server.</div>';
      console.log("DEBUG Response:", data);
    }
  } catch (e) {
    result.innerHTML = '<div class="error">Upload failed: ' + e.message + '</div>';
  }
});
