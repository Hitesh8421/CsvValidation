package com.example.csvvalidation.entities;

import java.util.List;


public class UploadResponse {
    private String status; 
    private List<ValidationError> errors;

    public UploadResponse() {}

    public UploadResponse(String status, List<ValidationError> errors) {
        this.status = status;
        this.errors = errors;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<ValidationError> getErrors() {
        return errors;
    }

    public void setErrors(List<ValidationError> errors) {
        this.errors = errors;
    }
}
