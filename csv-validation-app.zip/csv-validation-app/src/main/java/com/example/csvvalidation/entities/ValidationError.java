package com.example.csvvalidation.entities;


public class ValidationError {
    private long row;
    private String message;

    public ValidationError() {}

    public ValidationError(long row, String message) {
        this.row = row;
        this.message = message;
    }

    public long getRow() {
        return row;
    }

    public void setRow(long row) {
        this.row = row;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
