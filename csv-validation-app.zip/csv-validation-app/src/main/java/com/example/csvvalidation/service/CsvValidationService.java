package com.example.csvvalidation.service;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Service;

import com.example.csvvalidation.entities.ValidationError;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.List;

// ✅ Service contains the logic for parsing & validating CSV rows
@Service
public class CsvValidationService {

    // Strict date format yyyy-MM-dd
    private static final DateTimeFormatter STRICT_DATE = DateTimeFormatter.ofPattern("uuuu-MM-dd")
            .withResolverStyle(ResolverStyle.STRICT);

    public List<ValidationError> validate(InputStream in) throws IOException {
        List<ValidationError> errors = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            CSVFormat format = CSVFormat.DEFAULT.builder()
                    .setHeader()
                    .setSkipHeaderRecord(true) // skip first row (headers)
                    .build();

            try (CSVParser parser = new CSVParser(reader, format)) {
                for (CSVRecord record : parser) {
                    long rowNum = record.getRecordNumber(); // Row number (including header row = 1)

                    String name = record.get("Name") != null ? record.get("Name").trim() : "";
                    String dob = record.get("DateOfBirth") != null ? record.get("DateOfBirth").trim() : "";

                    // Check name
                    if (name.isEmpty()) {
                        errors.add(new ValidationError(rowNum, "Missing Name field"));
                    }

                    // Check date
                    if (dob.isEmpty()) {
                        errors.add(new ValidationError(rowNum, "Missing DateOfBirth field"));
                    } else {
                        try {
                            LocalDate.parse(dob, STRICT_DATE);
                        } catch (Exception e) {
                            errors.add(new ValidationError(rowNum,
                                    "Invalid date format/value: " + dob + " (expected yyyy-MM-dd)"));
                        }
                    }
                }
            }
        }

        return errors;
    }
}
