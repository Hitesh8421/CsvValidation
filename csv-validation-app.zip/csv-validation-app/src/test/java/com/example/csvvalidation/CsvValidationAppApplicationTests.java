package com.example.csvvalidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsvValidationAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
