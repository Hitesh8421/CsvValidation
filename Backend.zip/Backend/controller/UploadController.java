package com.example.csvvalidation.controller;


import com.example.csvvalidation.entities.UploadResponse;
import com.example.csvvalidation.entities.ValidationError;
import com.example.csvvalidation.service.CsvValidationService;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api")
public class UploadController {

    private final CsvValidationService csvValidationService;

    public UploadController(CsvValidationService csvValidationService) {
        this.csvValidationService = csvValidationService;
    }

    @PostMapping(
            path = "/upload",
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<UploadResponse> upload(@RequestParam("file") MultipartFile file) throws IOException {
        System.out.println("📂 Received upload: " + (file != null ? file.getOriginalFilename() : "null"));

        if (file == null || file.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(new UploadResponse("error",
                            List.of(new ValidationError(0, "No file uploaded"))));
        }

        List<ValidationError> errors = csvValidationService.validate(file.getInputStream());
        if (errors.isEmpty()) {
            return ResponseEntity.ok(new UploadResponse("success", List.of()));
        } else {
            return ResponseEntity.ok(new UploadResponse("error", errors));
        }
    }
}
